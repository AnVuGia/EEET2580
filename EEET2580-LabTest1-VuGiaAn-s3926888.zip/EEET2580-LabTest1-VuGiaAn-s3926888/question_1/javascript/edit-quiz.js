const currentQuestion = JSON.parse(localStorage.getItem('currentQuestion'));
const currentQuiz = JSON.parse(localStorage.getItem('currentQuiz'));
const listOfQuizzes = JSON.parse(localStorage.getItem('listOfQuizzes'));
const questionTitleEl = document.querySelector('#question-title');
const questionPointsEl = document.querySelector('#question-point');
const questionDescriptionEl = document.querySelector('#question-description');
const answerContainer = document.querySelector('#answer-container');
const container = document.querySelector('#edit-container');
const saveButton = document.querySelector('#save-button');
const cancelButton = document.querySelector('#cancel-button');
const deleteButton = document.querySelector('#delete-button');

cancelButton.addEventListener('click', (e) => {
  e.preventDefault();
  window.location.href = 'student-quiz.html';
});
deleteButton.addEventListener('click', (e) => {
  e.preventDefault();
  onDelete();
  window.location.href = 'student-quiz.html';
});
function updateUI() {
  questionTitleEl.value = currentQuestion.number;
  questionPointsEl.value = currentQuestion.question_points;
  questionDescriptionEl.value = currentQuestion.description;
  if (currentQuestion.answerType === 'multiple-choice') {
    onEditMultipleChoiceQuestion();
    saveButton.addEventListener('click', (e) => {
      e.preventDefault();
      onMultipleChoiceSave();
      window.location.href = 'student-quiz.html';
    });
  } else if (currentQuestion.answerType === 'essay-question') {
    onEditEssayQuestion();
    saveButton.addEventListener('click', (e) => {
      e.preventDefault();
      onEssaySave();
      window.location.href = 'student-quiz.html';
    });
  } else if (currentQuestion.answerType === 'matching-question') {
    onEditMatchingQuestion();
    saveButton.addEventListener('click', (e) => {
      e.preventDefault();
      onMatchingSave();
      window.location.href = 'student-quiz.html';
    });
  }
}
// multiple choice
function onEditMultipleChoiceQuestion() {
  console.log(currentQuestion);
  for (let i = 0; i < currentQuestion.answer.length; i++) {
    const answerEl = createMultipleChoiceAnswer(currentQuestion.answer[i]);
    answerContainer.appendChild(answerEl);
  }
  const addAnswerButton = document.createElement('button');
  addAnswerButton.setAttribute('class', 'btn btn-primary');
  addAnswerButton.textContent = 'Add answer';
  addAnswerButton.style.marginLeft = 'auto';
  const div = document.createElement('div');
  div.appendChild(addAnswerButton);
  div.classList.add('display-flex');
  addAnswerButton.addEventListener('click', (e) => {
    e.preventDefault();
    const answerEl = createMultipleChoiceAnswer('');
    answerContainer.appendChild(answerEl);
  });
  container.appendChild(div);
}
function createMultipleChoiceAnswer(answer) {
  const answerEl = document.createElement('li');
  answerEl.setAttribute('class', 'list-group-item');
  answerEl.classList.add('display-flex');
  const answerInput = createMultipleChoiceInput(answer);
  // answerInput.forEach((input) => {
  //   answerEl.appendChild(input);
  // });
  const checkLabel = document.createElement('div');
  const answerUti = document.createElement('div');
  checkLabel.appendChild(answerInput[2]);
  checkLabel.appendChild(answerInput[1]);
  checkLabel.classList.add('edit-checkboxLable');
  const deleteButton = createMultipleChoiceDeleteButton();
  answerUti.appendChild(checkLabel);
  answerUti.appendChild(deleteButton);
  answerUti.classList.add('edit-answer-ulti');
  deleteButton.classList.add('remove-answer');
  answerEl.appendChild(answerInput[0]);
  answerEl.appendChild(answerUti);
  return answerEl;
}
function createMultipleChoiceInput(value) {
  const answerEL = document.createElement('input');
  const answerCheck = document.createElement('input');
  const answerLabel = document.createElement('label');
  answerLabel.setAttribute('class', 'form-check-label');
  answerLabel.textContent = 'Correct';
  answerEL.appendChild(answerLabel);

  answerCheck.setAttribute('type', 'checkbox');
  answerCheck.setAttribute('id', 'answer-check');

  answerEL.setAttribute('type', 'text');
  answerEL.setAttribute('class', 'form-control');
  answerEL.setAttribute('placeholder', 'answer');
  answerEL.setAttribute('value', value);
  answerEL.setAttribute('id', 'answer-input');

  if (currentQuestion.correctAnswer.includes(value)) {
    answerCheck.checked = true;
  }
  return [answerEL, answerCheck, answerLabel];
}
function createMultipleChoiceDeleteButton() {
  const deleteButton = document.createElement('button');
  deleteButton.setAttribute('class', 'btn btn-danger');
  deleteButton.textContent = 'Delete';
  deleteButton.addEventListener('click', (e) => {
    e.preventDefault();
    deleteAnswer(deleteButton.parentElement);
  });
  return deleteButton;
}
function deleteAnswer(target) {
  const answerEl = target.parentElement;
  answerContainer.removeChild(answerEl);
}
function onMultipleChoiceSave() {
  const answer = [];
  const correctAnswer = [];
  const ul = document.querySelector('#answer-container');
  const answersList = ul.querySelectorAll('li');
  answersList.forEach((answerEl) => {
    const answerInput = answerEl.querySelector('#answer-input');
    const answerCheck = answerEl.querySelector('#answer-check');
    answer.push(answerInput.value);
    if (answerCheck.checked) {
      correctAnswer.push(answerInput.value);
    }
  });

  currentQuestion.answer = answer;
  currentQuestion.correctAnswer = correctAnswer;
  currentQuestion.title = questionTitleEl.value;
  currentQuestion.points = questionPointsEl.value;
  currentQuestion.description = questionDescriptionEl.value;
  const quizIndex = currentQuiz.questions.findIndex(
    (question) => question.number === currentQuestion.number
  );
  currentQuiz.questions[quizIndex] = currentQuestion;
  localStorage.setItem('currentQuiz', JSON.stringify(currentQuiz));
  localStorage.setItem('currentQuestion', JSON.stringify(currentQuestion));
  const quizIndex2 = listOfQuizzes.findIndex(
    (quiz) => quiz.id === currentQuiz.id
  );
  listOfQuizzes[quizIndex2] = currentQuiz;
  localStorage.setItem('listOfQuizzes', JSON.stringify(listOfQuizzes));
}
function onDelete() {
  const quizIndex = currentQuiz.questions.findIndex(
    (question) => question.number === currentQuestion.number
  );
  currentQuiz.questions.splice(quizIndex, 1);
  localStorage.setItem('currentQuiz', JSON.stringify(currentQuiz));
  localStorage.setItem('currentQuestion', JSON.stringify(currentQuestion));
  const quizIndex2 = listOfQuizzes.findIndex(
    (quiz) => quiz.id === currentQuiz.id
  );
  listOfQuizzes[quizIndex2] = currentQuiz;
  localStorage.setItem('listOfQuizzes', JSON.stringify(listOfQuizzes));
}
//essay
function onEditEssayQuestion() {
  console.log(currentQuestion);
  const answerEl = document.createElement('textarea');
  answerEl.setAttribute('class', 'form-control');
  answerEl.setAttribute('id', 'answer-input');
  answerEl.setAttribute('rows', '3');
  answerEl.textContent = currentQuestion.answer;
  answerContainer.appendChild(answerEl);
  saveButton.addEventListener('click', (e) => {
    e.preventDefault();
    onEssaySave();
    // window.location.href = 'student-quiz.html';
  });
}
function onEssaySave() {
  currentQuestion.answer = document.querySelector('#answer-input').value;
  currentQuestion.title = questionTitleEl.value;
  currentQuestion.points = questionPointsEl.value;
  currentQuestion.description = questionDescriptionEl.value;
  const quizIndex = currentQuiz.questions.findIndex(
    (question) => question.number === currentQuestion.number
  );
  currentQuiz.questions[quizIndex] = currentQuestion;
  localStorage.setItem('currentQuiz', JSON.stringify(currentQuiz));
  localStorage.setItem('currentQuestion', JSON.stringify(currentQuestion));
  const quizIndex2 = listOfQuizzes.findIndex(
    (quiz) => quiz.id === currentQuiz.id
  );
  listOfQuizzes[quizIndex2] = currentQuiz;
  localStorage.setItem('listOfQuizzes', JSON.stringify(listOfQuizzes));
}
// matching
function onEditMatchingQuestion() {
  console.log(currentQuestion);
  for (let i = 0; i < currentQuestion.correctAnswer.length; i++) {
    console.log(currentQuestion.answer[i]);
    const answerEl = createMatchingAnswer(currentQuestion.correctAnswer[i]);
    answerContainer.appendChild(answerEl);
  }
  const addAnswerButton = document.createElement('button');
  addAnswerButton.setAttribute('class', 'btn btn-primary');
  addAnswerButton.textContent = 'Add answer';
  addAnswerButton.style.marginLeft = 'auto';
  const div = document.createElement('div');
  div.appendChild(addAnswerButton);
  div.classList.add('display-flex');
  addAnswerButton.addEventListener('click', (e) => {
    e.preventDefault();
    const answerEl = createMatchingAnswer('');
    answerContainer.appendChild(answerEl);
  });
  container.appendChild(div);
  container.appendChild(createDistractions());

  saveButton.addEventListener('click', (e) => {
    e.preventDefault();
    onMatchingSave();
    // window.location.href = 'student-quiz.html';
  });
}
function createMatchingAnswer(answer) {
  console.log(answer);
  const answerEl = document.createElement('li');
  answerEl.setAttribute('class', 'list-group-item');
  const answerInput = createMatchingInput(answer);
  answerInput.forEach((input) => {
    answerEl.appendChild(input);
  });
  const deleteButton = createMatchingDeleteButton();
  answerEl.appendChild(deleteButton);
  return answerEl;
}
function createMatchingInput(value) {
  const firstHalf = document.createElement('input');
  firstHalf.setAttribute('type', 'text');
  firstHalf.setAttribute('class', 'form-control');
  firstHalf.setAttribute('placeholder', 'first half');
  firstHalf.setAttribute('value', value[0]);
  const secondHalf = document.createElement('input');
  secondHalf.setAttribute('type', 'text');
  secondHalf.setAttribute('class', 'form-control');
  secondHalf.setAttribute('placeholder', 'second half');
  secondHalf.setAttribute('value', value[1]);
  if (value === '') {
    firstHalf.setAttribute('value', '');
    secondHalf.setAttribute('value', '');
  }
  return [firstHalf, secondHalf];
}
function createDistractions() {
  const distractEl = document.createElement('textarea');
  let distractions = [];

  for (let i = 0; i < currentQuestion.answer.length; i++) {
    if (currentQuestion.correctAnswer[0].includes(currentQuestion.answer[i])) {
      continue;
    } else if (
      currentQuestion.correctAnswer[1].includes(currentQuestion.answer[i])
    ) {
      continue;
    } else {
      distractions.push(currentQuestion.answer[i]);
    }
  }
  console.log(currentQuestion.correctAnswer[0].includes(distractions[0]));
  console.log(distractions);
  let distract_string = '';
  for (let i = 0; i < distractions.length; i++) {
    distract_string += distractions[i] + '\n';
  }
  distractEl.setAttribute('class', 'form-control');
  distractEl.setAttribute('id', 'answer-input');
  distractEl.setAttribute('rows', '6');
  distractEl.textContent = distract_string;
  return distractEl;
}
function createMatchingDeleteButton() {
  const deleteButton = document.createElement('button');
  deleteButton.setAttribute('class', 'btn btn-danger');
  deleteButton.textContent = 'Delete';
  deleteButton.addEventListener('click', (e) => {
    e.preventDefault();
    deleteAnswer(e.target);
  });
  return deleteButton;
}
function onMatchingSave() {
  const correctAnswer = [];
  const ul = document.querySelector('#answer-container');
  for (let i = 0; i < ul.children.length; i++) {
    const li = ul.children[i];
    const input = li.children;
    const firstHalf = input[0].value;
    const secondHalf = input[1].value;
    correctAnswer.push([firstHalf, secondHalf]);
  }
  currentQuestion.correctAnswer = correctAnswer;
  currentQuestion.question_points = questionPointsEl.value;
  currentQuestion.description = questionDescriptionEl.value;
  currentQuestion.answer = [];
  const distractEl = document.querySelector('#answer-input');
  const distractions = distractEl.value.split('\n');
  console.log(distractions);
  for (let i = 0; i < distractions.length; i++) {
    if (distractions[i] === '') {
      continue;
    } else {
      currentQuestion.answer.push(distractions[i]);
    }
  }
  console.log(currentQuiz.questions);
  const quizIndex = currentQuiz.questions.findIndex(
    (question) => question.number === currentQuestion.number
  );
  console.log(quizIndex);
  currentQuiz.questions[quizIndex] = currentQuestion;
  localStorage.setItem('currentQuiz', JSON.stringify(currentQuiz));
  localStorage.setItem('currentQuestion', JSON.stringify(currentQuestion));
  const quizIndex2 = listOfQuizzes.findIndex(
    (quiz) => quiz.id === currentQuiz.id
  );
  listOfQuizzes[quizIndex2] = currentQuiz;
  localStorage.setItem('listOfQuizzes', JSON.stringify(listOfQuizzes));
}

updateUI();
