const quizList = document.querySelector('#quiz-list');
const userType = localStorage.getItem('userType');
const tableHead = document.querySelector('#table-head');
listOfQuizzes = localStorage.getItem('listOfQuizzes');
function onLoad() {
  console.log('onLoad');
  updateUI();
}
function updateUI() {
  let listOfQuizzes = localStorage.getItem('listOfQuizzes');
  if (listOfQuizzes === undefined || listOfQuizzes === null) {
    localStorage.setItem('listOfQuizzes', JSON.stringify([]));
  }
  listOfQuizzes = localStorage.getItem('listOfQuizzes');
  listOfQuizzes = JSON.parse(listOfQuizzes);
  console.log(listOfQuizzes);
  validateUser();
  quizList.innerHTML = '';
  if (userType === 'teacher') {
    const createQuizBtn = document.querySelector('#create-quiz');
    createQuizBtn.style.display = 'block';
    createQuizBtn.addEventListener('click', () => {
      window.location.href = 'add-quiz.html';
    });
    listOfQuizzes = sortArrayByStatus(listOfQuizzes);
    console.log(sortArrayByStatus(listOfQuizzes));
    tableHead.innerHTML = '';
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <th>Quiz Name</th>
              <th>Due Date</th>
              <th>Points</th>
              <th>Status</th>
              <th>Actions</th>
      `;
    tableHead.appendChild(tr);
    for (let item in listOfQuizzes) {
      const quiz = listOfQuizzes[item];
      console.log(quiz['status']);

      const row = document.createElement('tr');
      const titleEl = document.createElement('td');
      const statusEl = document.createElement('td');
      const pointsEl = document.createElement('td');
      const dueDateEl = document.createElement('td');
      const actionEl = document.createElement('td');

      const choiceBox = document.createElement('select');
      const defaultOption = document.createElement('option');
      const approveEl = document.createElement('option');
      const rejectedEl = document.createElement('option');
      const deleteEl = document.createElement('option');
      const editEl = document.createElement('option');
      defaultOption.textContent = 'Action';
      defaultOption.setAttribute('selected', 'selected');

      approveEl.textContent = 'Approve';
      rejectedEl.textContent = 'Reject';

      approveEl.value = 'approve';
      rejectedEl.value = 'reject';
      deleteEl.textContent = 'Delete';
      deleteEl.value = 'delete';
      editEl.textContent = 'Edit';
      editEl.value = 'edit';
      choiceBox.appendChild(defaultOption);
      if (quiz['status'] === 'accepted') {
        choiceBox.appendChild(rejectedEl);
      } else if (quiz['status'] === 'rejected') {
        choiceBox.appendChild(approveEl);
      } else {
        choiceBox.appendChild(approveEl);
        choiceBox.appendChild(rejectedEl);
      }
      choiceBox.appendChild(deleteEl);
      choiceBox.appendChild(editEl);

      choiceBox.addEventListener('change', (e) => {
        onChangeValueChoiceBox(e, quiz);
      });
      choiceBox.className = 'custom-select';
      choiceBox.setAttribute('selected', '   ');
      //end of choice box
      if (quiz['status'] === 'accepted') {
        statusEl.className = 'text-success';
      } else if (quiz['status'] === 'rejected') {
        statusEl.className = 'text-danger';
      } else {
        statusEl.className = 'text-warning';
      }

      titleEl.textContent = quiz['title'];
      statusEl.textContent = quiz['status'];
      pointsEl.textContent = quiz['quiz_points'];
      dueDateEl.textContent =
        quiz['dueDate'] === null ? 'No due date' : quiz['dueDate'];
      actionEl.appendChild(choiceBox);
      row.appendChild(titleEl);
      row.appendChild(dueDateEl);
      row.appendChild(pointsEl);
      row.appendChild(statusEl);
      row.appendChild(actionEl);
      quizList.appendChild(row);
    }
  }
  if (userType === 'student') {
    document.querySelector('#create-quiz').style.display = 'none';
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <th>Quiz Name</th>
                <th>Due Date</th>
                <th>Points</th>
                `;
    tableHead.appendChild(tr);
    const data = JSON.parse(localStorage.getItem('listOfQuizzes'));
    const filteredData = data.filter((item) => {
      return item.status === 'accepted';
    });
    for (let item in filteredData) {
      const quiz = filteredData[item];
      const row = document.createElement('tr');
      const titleEl = document.createElement('td');
      const pointsEl = document.createElement('td');
      const dueDateEl = document.createElement('td');
      titleEl.textContent = quiz['title'];
      titleEl.addEventListener('click', () => {
        onSwitchPage(quiz, 'student-quiz.html');
      });
      titleEl.style.cursor = 'pointer';
      titleEl.classList.add('text-primary');
      titleEl.classList.add('index-link-class');
      pointsEl.textContent = quiz['quiz_points'];
      dueDateEl.textContent =
        quiz['dueDate'] === null ? 'No due date' : quiz['dueDate'];
      row.appendChild(titleEl);
      row.appendChild(dueDateEl);
      row.appendChild(pointsEl);
      quizList.appendChild(row);
    }
  }
}

function onSwitchPage(quiz, url) {
  const quizJSON = JSON.stringify(quiz);
  localStorage.setItem('currentQuiz', quizJSON);
  window.location.href = url;
}
function onChangeValueChoiceBox(e, quiz) {
  if (e.target.value === 'delete') {
    onDelete(quiz);
  } else if (e.target.value === 'edit') {
    onEdit(quiz);
  } else if (e.target.value === 'reject' || e.target.value === 'approve') {
    onApproveReject(quiz, e.target.value);
  }
}
function onApproveReject(quiz, content) {
  const temp = JSON.parse(localStorage.getItem('listOfQuizzes'));
  console.log(temp);
  console.log('quiz');
  console.log(quiz);
  const index = temp.findIndex((item) => {
    console.log(item);
    return item.id === quiz.id;
  });
  console.log(index);
  const statusValue = { accepted: 0, pending: 1, rejected: 2 };
  if (statusValue[quiz['status']] === 0) {
    temp[index]['status'] = 'rejected';
  } else if (statusValue[quiz['status']] === 2) {
    temp[index]['status'] = 'accepted';
  } else {
    if (content === 'approve') {
      temp[index]['status'] = 'accepted';
    } else {
      temp[index]['status'] = 'rejected';
    }
  }
  localStorage.setItem('listOfQuizzes', JSON.stringify(temp));
  updateUI();
}
function onDelete(quiz) {
  const temp = JSON.parse(localStorage.getItem('listOfQuizzes'));
  const index = temp.findIndex((item) => item.id === quiz.id);
  console.log(index);
  temp.splice(index, 1);
  localStorage.setItem('listOfQuizzes', JSON.stringify(temp));
  updateUI();
}
function onEdit(quiz) {
  onSwitchPage(quiz, 'student-quiz.html');
}

//utility function to sort array by status
function sortArrayByStatus(array) {
  const statusOrder = { accepted: 0, pending: 1, rejected: 2 };
  return array.sort((a, b) => {
    if (statusOrder[a['status']] < statusOrder[b['status']]) return -1;
    if (statusOrder[a['status']] > statusOrder[b['status']]) return 1;
    console.log(statusOrder[a['status']]);
    return 0;
  });
}
function logOut() {
  localStorage.removeItem('userType');
  window.location.href = 'login.html';
}
const logOutBtn = document.querySelector('#logout');
logOutBtn.addEventListener('click', logOut);

/* <div class="quiz">
          <div class="quiz-text">
          <h4>Question</h4>
            <p>${Object.keys(quiz)[0]}</p>
            <h4>Answer</h4>
            <p>${quiz[Object.keys(quiz)[0]]}</p>
            </div>
            </div>`; */

onLoad();
