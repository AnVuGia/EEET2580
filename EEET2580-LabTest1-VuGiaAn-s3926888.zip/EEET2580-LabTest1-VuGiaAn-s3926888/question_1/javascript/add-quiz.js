const answerContainer = document.querySelector('#quiz-answer-container');
const quizType = document.querySelector('#quiz-type');
const question_points = document.querySelector('#question_points');
const description = document.querySelector('#quiz-info');
const listOfQuizzes = JSON.parse(localStorage.getItem('listOfQuizzes'));
const questionNumberEl = document.querySelector('#question-number');
const quizPoint = document.querySelector('#quiz-points');
const addQuizButtonEl = document.querySelector('#add-quiz');
const quizTitle = document.querySelector('#quiz-title');
const dueDate = document.querySelector('#date');
questionNumberEl.classList.add('align-text-bottom');
let questionNumber = 1;
let currentQuiz = {
  id: '',
  title: '',
  status: 'pending',
  dueDate: '',
  noQuestions: 0,
  quiz_points: quizPoint.value,
  questions: [],
};
quizType.addEventListener('change', () => {
  updateUI(quizType.value);
  console.log(quizType.value);
});

function updateUI(answerType) {
  questionNumberEl.textContent = questionNumber;

  answerContainer.innerHTML = '';
  if (answerType === 'multiple-choice') {
    multipleChoice();
  } else if (answerType === 'essay-question') {
    essayQuestion();
  } else if (answerType === 'matching-question') {
    matchingQuestion();
  }
}

// multiple choice
function multipleChoice() {
  const answer = document.createElement('input');
  const ul = document.createElement('ul');
  const addAnswerButton = document.createElement('button');
  const addQuizButton = document.createElement('button');
  addQuizButton.setAttribute('class', 'btn btn-primary');
  addQuizButton.textContent = 'Add Question';
  addQuizButton.addEventListener('click', (e) => {
    e.preventDefault();
    onAddMultipleChoiceQuiz();
    quizType.dispatchEvent(new Event('change'));
  });
  answer.setAttribute('type', 'text');
  answer.setAttribute('placeholder', 'answer');
  answer.setAttribute('class', 'form-control');
  answer.setAttribute('id', 'answer-input');

  addAnswerButton.setAttribute('class', 'btn btn-primary');
  addAnswerButton.textContent = 'Add answer';
  addAnswerButton.addEventListener('click', (e) => {
    e.preventDefault();
    appendMultipleChoice(ul, answer.value);
    answer.value = '';
  });
  ul.classList.add('answer-ul-container');
  answerContainer.appendChild(answer);
  answerContainer.appendChild(addAnswerButton);
  answerContainer.appendChild(ul);
  answerContainer.appendChild(addQuizButton);
}
// ultility
function appendMultipleChoice(ul, value) {
  console.log(value);
  const li = document.createElement('li');
  const answer = document.createElement('p');
  const check = document.createElement('input');
  const label = document.createElement('label');
  const remove = document.createElement('button');
  remove.setAttribute('class', 'btn btn-danger');
  remove.textContent = 'Remove';
  remove.addEventListener('click', (e) => {
    e.preventDefault();
    ul.removeChild(li);
  });
  check.setAttribute('type', 'checkbox');
  label.setAttribute('class', 'form-check-label');
  label.textContent = 'Correct';
  remove.classList.add('remove-answer');
  answer.textContent = value;
  const div = document.createElement('div');
  const checkboxDiv = document.createElement('div');
  checkboxDiv.classList.add('checkboxLable');
  checkboxDiv.appendChild(label);
  checkboxDiv.appendChild(check);

  div.appendChild(checkboxDiv);
  div.appendChild(remove);
  li.setAttribute('class', 'list-group-item');
  li.classList.add('display-flex');
  li.appendChild(answer);
  li.appendChild(div);
  div.classList.add('answer-ulti');
  ul.appendChild(li);
}
function onAddMultipleChoiceQuiz() {
  const answerType = document.querySelector('#quiz-type').value;
  const answer = [];
  const correctAnswer = [];
  const ul = document.querySelector('#quiz-answer-container ul');
  for (let i = 0; i < ul.children.length; i++) {
    const li = ul.children[i];
    const input = li.querySelector('p').textContent;
    const check = li.querySelector('input');

    answer.push(input);
    if (check.checked) {
      correctAnswer.push(input);
    }
  }

  const question = {
    number: questionNumber++,
    description: description.value,
    question_points: question_points.value,
    answerType: answerType,
    answer: answer,
    correctAnswer: correctAnswer,
  };
  currentQuiz.questions.push(question);
  console.log(currentQuiz);
}
//
function essayQuestion() {
  const textField = document.createElement('textarea');
  const addQuizButton = document.createElement('button');
  addQuizButton.setAttribute('class', 'btn btn-primary');
  addQuizButton.textContent = 'Add Question';
  addQuizButton.addEventListener('click', (e) => {
    e.preventDefault();
    onAddEssayQuiz();
    quizType.dispatchEvent(new Event('change'));
  });
  textField.setAttribute('class', 'form-control');
  textField.setAttribute('id', 'answer-input');
  textField.setAttribute('placeholder', 'suggest answer');
  textField.setAttribute('rows', '5');
  answerContainer.appendChild(textField);
  answerContainer.appendChild(addQuizButton);
}
function onAddEssayQuiz() {
  const answerType = document.querySelector('#quiz-type').value;
  const answer = document.querySelector('#answer-input').value;
  const question = {
    number: questionNumber++,
    description: description.value,
    question_points: question_points.value,
    answerType: answerType,
    answer: answer,
    correctAnswer: answer,
  };
  currentQuiz.questions.push(question);
  console.log(currentQuiz);
}
// matching question
function matchingQuestion() {
  const textFieldContainer = document.createElement('div');
  const textFieldLabel = document.createElement('label');
  const textField = document.createElement('textarea');
  const firstHalf = document.createElement('input');
  const secondHalf = document.createElement('input');
  const ul = document.createElement('ul');
  const addAnswerButton = document.createElement('button');
  const addQuizButton = document.createElement('button');
  textField.setAttribute('class', 'form-control');
  textField.setAttribute('id', 'answer-input');

  textField.setAttribute('rows', '5');
  textFieldLabel.textContent = 'Addional match possibility (distractors)';
  textFieldLabel.setAttribute('for', 'answer-input');
  textFieldContainer.appendChild(textFieldLabel);
  textFieldContainer.appendChild(textField);
  addQuizButton.setAttribute('class', 'btn btn-primary');
  addQuizButton.textContent = 'Add Question';
  addQuizButton.addEventListener('click', (e) => {
    e.preventDefault();
    onAddMatchingQuiz();
    quizType.dispatchEvent(new Event('change'));
  });
  firstHalf.setAttribute('type', 'text');
  firstHalf.setAttribute('placeholder', 'first half');
  firstHalf.setAttribute('class', 'form-control');
  firstHalf.setAttribute('id', 'first-half-input');
  secondHalf.setAttribute('type', 'text');
  secondHalf.setAttribute('placeholder', 'second half');
  secondHalf.setAttribute('class', 'form-control');
  secondHalf.setAttribute('id', 'second-half-input');
  addAnswerButton.setAttribute('class', 'btn btn-primary');
  addAnswerButton.textContent = 'Add answer';
  addAnswerButton.addEventListener('click', (e) => {
    e.preventDefault();
    appendMatching(ul, firstHalf.value, secondHalf.value);
    firstHalf.value = '';
    secondHalf.value = '';
  });
  answerContainer.appendChild(firstHalf);
  answerContainer.appendChild(secondHalf);
  answerContainer.appendChild(addAnswerButton);
  answerContainer.appendChild(ul);
  answerContainer.appendChild(textFieldContainer);
  answerContainer.appendChild(addQuizButton);
}
function appendMatching(ul, firstHalf, secondHalf) {
  const li = document.createElement('li');
  const firstHalfAnswer = document.createElement('p');
  const secondHalfAnswer = document.createElement('p');
  const remove = document.createElement('button');
  remove.setAttribute('class', 'btn btn-danger');
  remove.textContent = 'Remove';
  remove.addEventListener('click', (e) => {
    e.preventDefault();
    ul.removeChild(li);
  });
  firstHalfAnswer.textContent = firstHalf;
  secondHalfAnswer.textContent = secondHalf;
  li.setAttribute('class', 'list-group-item');
  li.appendChild(firstHalfAnswer);
  li.appendChild(secondHalfAnswer);
  li.appendChild(remove);
  ul.appendChild(li);
}
function onAddMatchingQuiz() {
  const answerType = document.querySelector('#quiz-type').value;
  const textValue = document.querySelector('#answer-input').value;
  const answer = [];
  const correctAnswer = [];
  const ul = document.querySelector('#quiz-answer-container ul');
  for (let i = 0; i < ul.children.length; i++) {
    const li = ul.children[i];
    const firstHalf = li.children[0].textContent;
    const secondHalf = li.children[1].textContent;
    const pair = [firstHalf, secondHalf];
    answer.push(firstHalf);
    answer.push(secondHalf);
    correctAnswer.push(pair);
  }
  if (textValue !== '') {
    const textValueArray = textValue.split('\n');
    textValueArray.forEach((text) => {
      answer.push(text);
    });
  }
  const question = {
    number: questionNumber++,
    description: description.value,
    question_points: question_points.value,
    answerType: answerType,
    answer: answer,
    correctAnswer: correctAnswer,
  };
  currentQuiz.questions.push(question);
  console.log(currentQuiz);
}

addQuizButtonEl.addEventListener('click', (e) => {
  currentQuiz.id = Math.floor(Math.random() * 1000000);
  currentQuiz.title = quizTitle.value;
  currentQuiz.quiz_points = quizPoint.value;
  currentQuiz.dueDate = dueDate === null ? null : dueDate.value;
  currentQuiz.noQuestions = questionNumber - 1;
  listOfQuizzes.push(currentQuiz);
  localStorage.setItem('listOfQuizzes', JSON.stringify(listOfQuizzes));
});
const backBtn = document.querySelector('#back');
backBtn.addEventListener('click', (e) => {
  e.preventDefault();
  window.location.href = 'index.html';
});
quizType.dispatchEvent(new Event('change'));
