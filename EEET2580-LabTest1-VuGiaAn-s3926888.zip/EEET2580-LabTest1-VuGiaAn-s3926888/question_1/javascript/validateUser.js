function validateUser() {
  const userType = localStorage.getItem('userType');
  if (userType === undefined || userType === null) {
    window.location.href = 'login.html';
  }
}
