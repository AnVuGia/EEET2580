function onTeacherLogin() {
  localStorage.setItem('userType', 'teacher');
  window.location.href = 'index.html';
}
function onStudentLogin() {
  localStorage.setItem('userType', 'student');
  window.location.href = 'index.html';
}
document
  .querySelector('#teacher-login')
  .addEventListener('click', onTeacherLogin);
document
  .querySelector('#student-login')
  .addEventListener('click', onStudentLogin);
