const currentQuiz = JSON.parse(localStorage.getItem('currentQuiz'));
const questionList = document.querySelector('#question-list');
const quizTitle = document.querySelector('#quiz-title');
const summitButton = document.querySelector('#submit-quiz');
const listOfQuizzes = JSON.parse(localStorage.getItem('listOfQuizzes'));
const userType = localStorage.getItem('userType');
const goBackButton = document.querySelector('#go-back');
goBackButton.addEventListener('click', (e) => {
  e.preventDefault();
  window.location.href = 'index.html';
});
//student quiz
function updateUI() {
  if (userType === 'student') {
    summitButton.classList.remove('hidden');
    summitButton.classList.add('show');
  } else {
    summitButton.classList.remove('show');
    summitButton.classList.add('hidden');
  }
  getQuizQuestions();
}
function getQuizQuestions() {
  const questions = currentQuiz.questions;
  console.log(questions);
  quizTitle.textContent = currentQuiz.title;

  for (let question in questions) {
    if (questions[question].answerType === 'multiple-choice') {
      const questionEl = document.createElement('div');
      questionEl.setAttribute('class', ' centered');
      questionEl.appendChild(createMultipleChoiceQuestion(questions[question]));
      questionEl.appendChild(createMultipleChoiceAnswer(questions[question]));
      questionList.appendChild(questionEl);
    } else if (questions[question].answerType === 'essay-question') {
      createEssayQuestion(questions[question]);
    } else if (questions[question].answerType === 'matching-question') {
      createMatchingQuestion(questions[question]);
    }
    if (userType === 'teacher') {
      summitButton.classList.add('hidden');

      console.log(listOfQuizzes);
      const div = document.createElement('div');
      div.style.display = 'flex';
      const editButton = document.createElement('button');
      div.appendChild(editButton);
      questionList.appendChild(div);
      editButton.setAttribute('class', 'btn btn-primary');
      editButton.classList.add('edit-button-in-quiz');
      editButton.textContent = 'Edit';
      editButton.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.setItem(
          'currentQuestion',
          JSON.stringify(questions[question])
        );
        window.location.href = 'edit-quiz.html';
      });
    } else {
    }
  }
}

function createMultipleChoiceQuestion(question) {
  const questionEl = document.createElement('div');

  const questionTitleEl = document.createElement('h3');
  questionTitleEl.textContent = 'Question ' + question['number'];
  const questionDescriptionEl = document.createElement('p');
  questionDescriptionEl.textContent = question['description'];
  const pointsEl = document.createElement('p');
  pointsEl.textContent = 'Points: ' + question['question_points'];
  questionDescriptionEl.setAttribute('class', 'question-description');
  pointsEl.setAttribute('class', 'question-points');
  questionEl.appendChild(questionTitleEl);
  questionEl.appendChild(questionDescriptionEl);
  questionEl.appendChild(pointsEl);
  return questionEl;
}
function createMultipleChoiceAnswer(question) {
  const answerEl = document.createElement('ul');
  answerEl.setAttribute('class', 'list-group');

  const answers = question.answer;
  console.log(answers);
  for (let answer in answers) {
    const answerLi = createCheckboxItem(answers[answer]);
    answerEl.appendChild(answerLi);
  }
  return answerEl;
}
function createCheckboxItem(value) {
  const container = document.createElement('div');
  container.setAttribute('class', 'form-check');
  const checkbox = document.createElement('input');
  checkbox.setAttribute('type', 'checkbox');
  checkbox.setAttribute('class', 'form-check-input');
  const label = document.createElement('label');
  label.setAttribute('class', 'form-check-label');
  label.textContent = value;
  const li = document.createElement('li');
  li.setAttribute('class', 'list-group-item');
  container.appendChild(checkbox);
  container.appendChild(label);
  li.appendChild(container);
  return li;
}
//
function createEssayQuestion(question) {
  const questionEl = document.createElement('div');
  questionEl.setAttribute('class', ' centered');
  questionEl.appendChild(createEssayQuestionTitle(question));
  questionEl.appendChild(createEssayQuestionDescription(question));
  questionEl.appendChild(createEssayQuestionPoints(question));
  questionEl.appendChild(createEssayQuestionAnswer(question));
  questionList.appendChild(questionEl);
}
function createEssayQuestionTitle(question) {
  const questionTitleEl = document.createElement('h3');
  questionTitleEl.textContent = 'Question ' + question['number'];
  return questionTitleEl;
}
function createEssayQuestionDescription(question) {
  const questionDescriptionEl = document.createElement('p');
  questionDescriptionEl.textContent = question['description'];
  questionDescriptionEl.setAttribute('class', 'question-description');

  return questionDescriptionEl;
}
function createEssayQuestionPoints(question) {
  const pointsEl = document.createElement('p');
  pointsEl.textContent = 'Points: ' + question['question_points'];
  pointsEl.setAttribute('class', 'question-points');
  return pointsEl;
}
function createEssayQuestionAnswer() {
  const answerEl = document.createElement('textarea');
  answerEl.setAttribute('class', 'form-control');
  answerEl.setAttribute('rows', '3');
  return answerEl;
}
//
function createMatchingQuestion(question) {
  const questionEl = document.createElement('div');
  questionEl.setAttribute('class', ' centered');
  questionEl.appendChild(createMatchingQuestionTitle(question));
  questionEl.appendChild(createMatchingQuestionDescription(question));
  questionEl.appendChild(createMatchingQuestionPoints(question));
  questionEl.appendChild(createMatchingQuestionAnswer(question));
  questionList.appendChild(questionEl);
}
function createMatchingQuestionTitle(question) {
  const questionTitleEl = document.createElement('h3');
  questionTitleEl.textContent = 'Question ' + question['number'];
  return questionTitleEl;
}
function createMatchingQuestionDescription(question) {
  const questionDescriptionEl = document.createElement('p');
  questionDescriptionEl.textContent = question['description'];
  questionDescriptionEl.setAttribute('class', 'question-description');
  return questionDescriptionEl;
}
function createMatchingQuestionPoints(question) {
  const pointsEl = document.createElement('p');
  pointsEl.textContent = 'Points: ' + question['question_points'];
  pointsEl.setAttribute('class', 'question-points');
  return pointsEl;
}
function createMatchingQuestionAnswer(question) {
  const answerEl = document.createElement('ul');
  answerEl.setAttribute('class', 'list-group');
  const correctAnswers = question.correctAnswer;
  const answers = question.answer;
  for (let answer in correctAnswers) {
    const answerLi = createMatchingItem(correctAnswers[answer][0], answers);
    answerEl.appendChild(answerLi);
  }
  return answerEl;
}
function createMatchingItem(firstHalf, answers) {
  const li = document.createElement('li');
  li.setAttribute('class', 'list-group-item');
  const container = document.createElement('div');
  const secondHalfEl = document.createElement('select');
  secondHalfEl.setAttribute('class', 'form-control');
  const firstHalfEl = document.createElement('p');
  firstHalfEl.textContent = firstHalf;
  for (let answer in answers) {
    if (answers[answer] === firstHalf) {
      continue;
    }
    const option = document.createElement('option');
    option.textContent = answers[answer];
    secondHalfEl.appendChild(option);
  }
  container.appendChild(firstHalfEl);
  container.appendChild(secondHalfEl);
  container.setAttribute('class', 'form-group');
  container.setAttribute('style', 'display: flex;');
  container.classList.add(
    'centered',
    'justify-content-between',
    'w-100',
    'mb-3',
    'mt-3',
    'bg-light'
  );
  firstHalfEl.setAttribute('style', 'width: 50%;');
  firstHalfEl.classList.add(
    'border',
    'border-dark',
    'p-2',
    'rounded',
    'bg-light'
  );
  secondHalfEl.setAttribute('style', 'width: 50%;');
  li.appendChild(container);

  return li;
}
function onQuizSubmit() {
  for (let index = 0; index < currentQuiz.questions.length; index++) {
    if (currentQuiz.questions[index].answerType === 'multiple-choice') {
      if (checkMultipleChoiceAnswer(questionList.childNodes[index], index)) {
        currentQuiz.questions[index].studentAnswer = 'correct';
        questionList.childNodes[index].classList.add('correct');
      } else {
        currentQuiz.questions[index].studentAnswer = 'incorrect';
        questionList.childNodes[index].classList.add('incorrect');
      }
    } else if (currentQuiz.questions[index].answerType === 'essay-question') {
      currentQuiz.questions[index].studentAnswer =
        questionList.childNodes[index].childNodes[3].value;
    } else if (
      currentQuiz.questions[index].answerType === 'matching-question'
    ) {
      if (checkMatchingAnswer(questionList.childNodes[index], index)) {
        currentQuiz.questions[index].studentAnswer = 'correct';
        questionList.childNodes[index].classList.add('correct');
      } else {
        currentQuiz.questions[index].studentAnswer = 'incorrect';
        questionList.childNodes[index].classList.add('incorrect');
      }
    }
  }
  saveQuiz();
  displayPoints();
  summitButton.setAttribute('disabled', 'disabled');
}
function checkMultipleChoiceAnswer(question, index) {
  const answerNodes = question.querySelectorAll('input');
  const correctAnswers = currentQuiz.questions[index].correctAnswer;
  const studentAnswer = [];
  let correct = true;
  for (let answer in answerNodes) {
    if (answerNodes[answer].checked) {
      if (
        !correctAnswers.includes(answerNodes[answer].nextSibling.textContent)
      ) {
        correct = false;
      } else {
        studentAnswer.push(answerNodes[answer].nextSibling.textContent);
      }
    }
  }
  if (studentAnswer.length !== correctAnswers.length) {
    correct = false;
  }
  return correct;
}
function checkMatchingAnswer(question, index) {
  const answerNodes = question.querySelectorAll('select');
  const correctAnswers = currentQuiz.questions[index].correctAnswer;
  let correct = true;
  for (let answer in currentQuiz.questions[index].correctAnswer) {
    if (answerNodes[answer].value !== correctAnswers[answer][1]) {
      correct = false;
    }
  }
  return correct;
}
function saveQuiz() {
  const newEl = (listOfQuizzes.find(
    (quiz) => quiz.id === currentQuiz.id
  ).questions = [...currentQuiz.questions]);
  console.log(newEl);
  localStorage.setItem('listOfQuizzes', JSON.stringify(listOfQuizzes));
}
function displayPoints() {
  let points = 0;
  for (let question in currentQuiz.questions) {
    if (currentQuiz.questions[question].studentAnswer === 'correct') {
      points += parseInt(currentQuiz.questions[question].question_points);
    }
  }
  const pointsEl = document.createElement('h2');
  pointsEl.textContent =
    'You got ' +
    points +
    ' points!, if there is an essay question, the points will be added after the teacher grades it.';
  pointsEl.setAttribute('class', 'centered');
  questionList.appendChild(pointsEl);
}
getQuizQuestions();
summitButton.addEventListener('click', onQuizSubmit);
//
