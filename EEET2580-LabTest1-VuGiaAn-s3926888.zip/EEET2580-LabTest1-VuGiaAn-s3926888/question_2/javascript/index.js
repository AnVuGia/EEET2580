const pokemonContainer = document.querySelector('#pokemon-list-container');
const pokemonModal = document.querySelector('#pokemonModal');
const closeBtn = document.querySelector('#close-btn');
const pokemonTypeFilter = document.querySelector('#type');
const pokemonSort = document.querySelector('#sort');
const pagination = document.querySelector('#pagination');
const search = document.querySelector('#search');
const searchBtn = document.querySelector('#search-btn');
let nextURL = null;
let prevURL = null;
let nextBtn = null;
let prevBtn = null;
closeBtn.setAttribute('data-bs-dismiss', 'modal');
closeBtn.setAttribute('aria-label', 'Close');
let customOffset = 0;
const customLimit = 300;
closeBtn.addEventListener('click', () => {
  $('#pokemonModal').modal('hide');
});
//spinner
const loadingSpinner = document.getElementById('loading-spinner');

function showLoadingSpinner() {
  loadingSpinner.classList.remove('hidden');
  loadingSpinner.classList.add('show');
}

function hideLoadingSpinner() {
  console.log('hide');
  loadingSpinner.classList.remove('show');
  loadingSpinner.classList.add('hidden');
}
//
const limit = 10;
let offset = 0;
let baseURL = 'https://pokeapi.co/api/v2/pokemon';
let pokemonList = [];
let pokemonListData = [];
// const prevBtn = document.querySelector('#prev-btn');
// const nextBtn = document.querySelector('#next-btn');
async function getPokemon(endpoint) {
  const response = await fetch(endpoint);
  console.log(response);
  const data = await response.json();
  console.log(data);
  const pokemon = data.results;
  nextURL = data.next;
  prevURL = data.previous;
  return pokemon;
}
async function getPokemonByType(type) {
  currentURL = `https://pokeapi.co/api/v2/type/${type}/`;
  const response = await fetch(currentURL);
  const data = await response.json();
  const pokemon = data.pokemon;
  return pokemon;
}
// const getPokemonInfo = async (getFunc) => {
//   const pokemon = await getFunc();
//   for (let i = 0; i < pokemon.length; i++) {
//     const pokemonUrl = pokemon[i].url;
//     const pokemonInfo = await fetch(pokemonUrl);
//     const pokemonData = await pokemonInfo.json();
//     pokemonList.push(pokemonData);
//   }
//   displayPokemon();
// };
const displayPokemon = () => {
  console.log(pokemonListData);
  pokemonListData.forEach((pokemon) => {
    const pokemonCard = createPokemonCard(pokemon);
    pokemonCard.setAttribute('data-bs-toggle', 'modal');
    pokemonCard.setAttribute('data-bs-target', '#pokemonModal');
    pokemonCard.addEventListener('click', () => {
      $('#pokemonModal').modal('show');
      updateModal(pokemon);
    });
    pokemonContainer.appendChild(pokemonCard);
  });
};
const updateModal = async (pokemon) => {
  console.log('update');
  const modalTitle = document.querySelector('.modal-title');
  const modalBody = document.querySelector('.modal-body');
  let name = pokemon.name;
  const type = pokemon.types[0].type.name;
  name = name[0].toUpperCase() + name.slice(1);
  modalTitle.innerHTML = name;
  modalBody.innerHTML = `
    <div class="poke-image">
    <img src=${pokemon.sprites.front_default} alt="Pokemon Image">
    </div>
    <div class="poke-info">
    <h3 class="poke-name">${name}</h3>
    <div class="poke-types">
        
    </div>
     <p id="pokemon-description"></p>
     <button class="read-more" id="read-more-des">Read More</button>
    <ul id="pokemon-stats">
        <li><strong>Height:</strong> <span id="pokemon-height"></span></li>
        <li><strong>Weight:</strong> <span id="pokemon-weight"></span></li>
    </ul>
    <h3>Moves:</h3>
    <div id="pokemon-moves"></div>
    <button class="read-more" id="read-more-move">Read More</button>
    <h3>Habitat:</h3>
    <div id="pokemon-habitat"></div>
    </div>
    `;
  for (let i = 0; i < pokemon.types.length; i++) {
    const type = pokemon.types[i].type.name;
    const typeEl = document.createElement('span');
    typeEl.classList.add('poke-type');
    typeEl.textContent = type;
    modalBody.querySelector('.poke-types').appendChild(typeEl);
    addColortoEl(type, typeEl);
  }

  const pokeAPI = 'https://pokeapi.co/api/v2/';
  const speciesResponse = await fetch(
    `${pokeAPI}pokemon-species/${pokemon.id}`
  );
  const speciesData = await speciesResponse.json();
  console.log(speciesData);
  const pokemonDescription = modalBody.querySelector('#pokemon-description');
  const pokemonHeight = modalBody.querySelector('#pokemon-height');
  const pokemonWeight = modalBody.querySelector('#pokemon-weight');
  const pokemonMoves = modalBody.querySelector('#pokemon-moves');
  const pokemonHabitat = modalBody.querySelector('#pokemon-habitat');
  const readMoreDes = modalBody.querySelector('#read-more-des');
  const readMoreMove = modalBody.querySelector('#read-more-move');
  const habitat =
    speciesData.habitat.name[0].toUpperCase() +
    speciesData.habitat.name.slice(1);
  pokemonHabitat.innerHTML = habitat;

  pokemonHeight.innerHTML = pokemon.height;
  pokemonWeight.innerHTML = pokemon.weight;
  let move_count = 0;
  pokemon.moves.forEach((move) => {
    const moveName = move.move.name;
    const moveItem = document.createElement('p');
    if (move_count > 10) {
      moveItem.classList.add('hidden');
    }
    move_count++;

    moveItem.innerHTML = moveName;
    pokemonMoves.appendChild(moveItem);
  });
  readMoreMove.addEventListener('click', () => {
    const hidden = pokemonMoves.querySelectorAll('.hidden');
    hidden.forEach((p) => {
      p.classList.remove('hidden');
    });
    readMoreMove.style.display = 'none';
  });

  let count = 0;
  speciesData.flavor_text_entries.forEach((entry) => {
    if (entry.language.name === 'en') {
      if (pokemonDescription.textContent.includes(entry.flavor_text)) {
        return;
      }

      const p = document.createElement('p');
      if (count > 4) {
        p.classList.add('hidden');
      }
      p.textContent = entry.flavor_text;
      pokemonDescription.appendChild(p);
      count++;
    }
  });
  readMoreDes.addEventListener('click', () => {
    const hidden = pokemonDescription.querySelectorAll('.hidden');
    hidden.forEach((p) => {
      p.classList.remove('hidden');
    });
    readMoreDes.style.display = 'none';
  });
};

async function updateUI(response) {
  showLoadingSpinner();
  if (prevURL !== null || offset > 0) {
    prevBtn.disabled = false;
  } else {
    prevBtn.disabled = true;
  }
  if (nextURL !== null || offset < pokemonList.length) {
    nextBtn.disabled = false;
  } else {
    nextBtn.disabled = true;
  }
  pokemonContainer.innerHTML = '';

  const pokemon = response;
  console.log(pokemon[0]);
  pokemonListData = [];
  for (let i = 0; i < pokemon.length; i++) {
    console.log(pokemon[i].url);
    const pokemonName = pokemon[i].name;
    const pokemonUrl = pokemon[i].url;
    const pokemonInfo = await fetch(pokemonUrl);
    const pokemonData = await pokemonInfo.json();
    pokemonListData.push(pokemonData);
  }

  displayPokemon();
  hideLoadingSpinner();
}

//create card function
function createPokemonCard(pokemon) {
  let name = pokemon.name;
  name = name[0].toUpperCase() + name.slice(1);
  const img = pokemon.sprites.front_default;
  const type = pokemon.types[0].type.name;
  const hp = pokemon.stats[0].base_stat;
  const attack = pokemon.stats[1].base_stat;
  const defense = pokemon.stats[2].base_stat;
  const spAtk = pokemon.stats[3].base_stat;
  const spDef = pokemon.stats[4].base_stat;
  const speed = pokemon.stats[5].base_stat;
  const pokemonCard = document.createElement('div');
  pokemonCard.innerHTML = `
    <div class="poke-card">
  
  <div class="poke-image">
    <img src=${img} alt="Pokemon Image">
  </div>
  <div class="poke-info">
    <h3 class="poke-name">${name}</h3>
    <div class="poke-types">
      
    </div>
    <div class="poke-stats">
      <div class="poke-stat">
        <span class="poke-stat-name">HP:</span>
        <span class="poke-stat-value">${hp}</span>
      </div>
      <div class="poke-stat">
        <span class="poke-stat-name">Attack:</span>
        <span class="poke-stat-value">${attack}</span>
      </div>
      <div class="poke-stat">
        <span class="poke-stat-name">Defense:</span>
        <span class="poke-stat-value">${defense}</span>
      </div>
      <div class="poke-stat">
        <span class="poke-stat-name">Sp. Atk:</span>
        <span class="poke-stat-value">${spAtk}</span>
      </div>
      <div class="poke-stat">
        <span class="poke-stat-name">Sp. Def:</span>
        <span class="poke-stat-value">${spDef}</span>
      </div>
      <div class="poke-stat">
        <span class="poke-stat-name">Speed:</span>
        <span class="poke-stat-value">${speed}</span>
      </div>
    </div>
  </div>
</div>
    `;
  const typeEl = pokemonCard.querySelector('.poke-type');
  for (let i = 0; i < pokemon.types.length; i++) {
    const type = pokemon.types[i].type.name;
    const typeEl = document.createElement('span');
    typeEl.classList.add('poke-type');
    typeEl.textContent = type;
    pokemonCard.querySelector('.poke-types').appendChild(typeEl);
    addColortoEl(type, typeEl);
  }

  return pokemonCard;
}
function addColortoEl(type, el) {
  if (type === 'grass') {
    el.classList.add('grass');
  } else if (type === 'fire') {
    el.classList.add('fire');
  } else if (type === 'water') {
    el.classList.add('water');
  } else if (type === 'bug') {
    el.classList.add('bug');
  } else if (type === 'normal') {
    el.classList.add('normal');
  } else if (type === 'poison') {
    el.classList.add('poison');
  } else if (type === 'electric') {
    el.classList.add('electric');
  } else if (type === 'ground') {
    el.classList.add('ground');
  } else if (type === 'fairy') {
    el.classList.add('fairy');
  } else if (type === 'fighting') {
    el.classList.add('fighting');
  } else if (type === 'psychic') {
    el.classList.add('psychic');
  } else if (type === 'rock') {
    el.classList.add('rock');
  } else if (type === 'ghost') {
    el.classList.add('ghost');
  } else if (type === 'ice') {
    el.classList.add('ice');
  } else if (type === 'dragon') {
    el.classList.add('dragon');
  } else if (type === 'dark') {
    el.classList.add('dark');
  } else if (type === 'steel') {
    el.classList.add('steel');
  } else if (type === 'flying') {
    el.classList.add('flying');
  }
}
async function onFilterTypeChange(e) {
  if (nextBtn !== null) {
    pagination.removeChild(nextBtn);
    pagination.removeChild(prevBtn);
  }
  nextBtn = createNextBtn();
  prevBtn = createPrevBtn();
  pagination.appendChild(prevBtn);
  pagination.appendChild(nextBtn);
  const type = e.target.value.toLowerCase();
  offset = 0;
  pokemonList = [];
  if (type === 'all') {
    showLoadingSpinner();
    currentURL = baseURL;
    const data = await getPokemon(
      currentURL + `?offset=${offset}&limit=${limit}`
    );
    pokemonList = data;
    console.log(data);
    console.log(pokemonList);
    hideLoadingSpinner();
    updateUI(pokemonList);
    prevBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      offset -= limit;
      const data = await getPokemon(prevURL);
      updateUI(data);
    });
    nextBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      offset += limit;
      const data = await getPokemon(nextURL);
      updateUI(data);
    });
  } else {
    pokemonList = [];
    showLoadingSpinner();
    currentURL = 'https://pokeapi.co/api/v2/type';
    const data = await getPokemon(currentURL);
    console.log(data);
    const typeInfo = data.find(
      (typeInfo) => typeInfo.name === type.toLowerCase()
    );
    console.log(typeInfo);
    const typdeData = await (await fetch(typeInfo.url)).json();
    typdeData.pokemon.forEach((pokemon) => {
      pokemonList.push(pokemon.pokemon);
    });

    console.log(pokemonList);
    const response = pokemonList.slice(offset, offset + limit);
    hideLoadingSpinner();
    console.log(response);
    updateUI(response);
    prevBtn.addEventListener('click', (e) => {
      e.preventDefault();
      offset -= limit;
      console.log(offset);
      const data = pokemonList.slice(offset, offset + limit);
      updateUI(data);
    });
    nextBtn.addEventListener('click', () => {
      e.preventDefault();
      offset += limit;
      console.log(offset);
      const data = pokemonList.slice(offset, offset + limit);
      updateUI(data);
    });
  }
}
async function onSortByChange() {
  currentURL = baseURL;
  const sortBy = pokemonSort.value;
  offset = 0;

  customOffset = 0;
  if (nextBtn !== null) {
    pagination.removeChild(nextBtn);
    pagination.removeChild(prevBtn);
  }
  nextBtn = createNextBtn();
  prevBtn = createPrevBtn();
  pagination.appendChild(prevBtn);
  pagination.appendChild(nextBtn);
  if (sortBy === 'a-z') {
    if (pokemonTypeFilter.value === 'all') {
      pokemonList = await getPokemon(
        currentURL + `?offset=0&limit=${customLimit}`
      );
    }
    console.log(pokemonList);
    pokemonList.sort((a, b) => a.name.localeCompare(b.name));
  } else if (sortBy === 'z-a') {
    if (pokemonTypeFilter.value === 'all') {
      pokemonList = await getPokemon(
        currentURL + `?offset=0&limit=${customLimit}`
      );
    }
    pokemonList.sort((a, b) => b.name.localeCompare(a.name));
  } else {
    pokemonTypeFilter.dispatchEvent(new Event('change'));
    return;
  }

  updateUI(pokemonList.slice(offset, offset + limit));
  prevBtn.addEventListener('click', (e) => {
    e.preventDefault();
    offset -= limit;
    console.log(offset);
    const data = pokemonList.slice(offset, offset + limit);
    updateUI(data);
  });
  nextBtn.addEventListener('click', (e) => {
    e.preventDefault();
    offset += limit;
    console.log(offset);
    const data = pokemonList.slice(offset, offset + limit);
    updateUI(data);
  });
}
function createNextBtn() {
  const nextBtn = document.createElement('button');
  nextBtn.classList.add('next-btn', 'btn', 'btn-primary');
  nextBtn.textContent = 'Next';
  return nextBtn;
}
function createPrevBtn() {
  const prevBtn = document.createElement('button');
  prevBtn.classList.add('prev-btn', 'btn', 'btn-primary');
  prevBtn.textContent = 'Prev';
  return prevBtn;
}
async function getSearchPokemon() {
  prevURL = null;
  nextURL = null;
  const searchURL = 'https://pokeapi.co/api/v2/pokemon';
  const searchValue = search.value.toLowerCase().trim();
  showLoadingSpinner();
  if (searchValue === '') {
    location.reload();
  }

  pokemonContainer.innerHTML = '';
  pokemonList = [];

  try {
    const data = await fetch(searchURL + `/${searchValue}`);
    hideLoadingSpinner();
    const pokemon = await data.json();
    const pokemonEl = createPokemonCard(pokemon);
    pokemonContainer.appendChild(pokemonEl);
    pokemonEl.setAttribute('data-bs-toggle', 'modal');
    pokemonEl.setAttribute('data-bs-target', '#pokemonModal');
    pokemonEl.addEventListener('click', () => {
      $('#pokemonModal').modal('show');

      updateModal(pokemon);
    });
    search.value = '';
  } catch (error) {
    hideLoadingSpinner();
    const errorEl = createSearchError();
    pokemonContainer.appendChild(errorEl);
  }
}
function createSearchError() {
  const error = document.createElement('div');
  error.classList.add('error');
  error.textContent = 'Pokemon not found';
  return error;
}
pokemonTypeFilter.addEventListener('change', onFilterTypeChange);
pokemonTypeFilter.dispatchEvent(new Event('change'));
pokemonSort.addEventListener('change', onSortByChange);
searchBtn.addEventListener('click', (e) => {
  e.preventDefault();
  getSearchPokemon();
});
