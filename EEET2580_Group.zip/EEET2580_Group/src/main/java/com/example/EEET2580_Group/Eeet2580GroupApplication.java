package com.example.EEET2580_Group;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Eeet2580GroupApplication {

	public static void main(String[] args) {
		SpringApplication.run(Eeet2580GroupApplication.class, args);
	}

}
