package com.example.EEET2580_Group;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Eeet2580GroupApplicationTests {

	@Test
	void contextLoads() {
	}

}
