package com.example.week6tut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week6tutApplicationTests {

	@Test
	void contextLoads() {
	}

}
